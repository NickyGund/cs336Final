# cs336Final
 
CS336
Professor Miranda
Group 4

Steve Nguyen (shn27)
	Project lead
	Set up Amazon RDS, EC2
	Advised team members on code related issues
	Code contribution credited in checklist.txt
Thomas Fiorilla (trf40)
	Code contribution credited on JSP pages/checklist.txt
Nicolas Gundersen (neg62)
	Code contribution credited on JSP pages/checklist.txt
Salman Saeed (sms786)
	MySQL Database data input and maintenance
Anthony Tiongson (ast119)
	Code contribution credited on JSP pages/checklist.txt


Link to Manager:
	http://ec2-18-222-131-43.us-east-2.compute.amazonaws.com:8080
Link to App:
	http://ec2-18-222-131-43.us-east-2.compute.amazonaws.com:8080/cs336Final/
user: admin
pass: pass

RDS Hostname: steve2.ckgj9bgqpyor.us-east-2.rds.amazonaws.com:3306
user: admin
pass: password